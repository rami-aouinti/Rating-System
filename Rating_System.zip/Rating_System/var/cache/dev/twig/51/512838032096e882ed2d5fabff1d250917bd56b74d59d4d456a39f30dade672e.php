<?php

/* NelmioApiDocBundle::Components/motd.html.twig */
class __TwigTemplate_b2d55771ae6de94de294e26bf5fdc839e3ad263351633b560d76fa47f846b423 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_85698884d9b2329b4bcbdd7f3dd60b43f8f0db3ad1768b4388399fc0ce312482 = $this->env->getExtension("native_profiler");
        $__internal_85698884d9b2329b4bcbdd7f3dd60b43f8f0db3ad1768b4388399fc0ce312482->enter($__internal_85698884d9b2329b4bcbdd7f3dd60b43f8f0db3ad1768b4388399fc0ce312482_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "NelmioApiDocBundle::Components/motd.html.twig"));

        // line 1
        echo "<div class=\"motd\"></div>
";
        
        $__internal_85698884d9b2329b4bcbdd7f3dd60b43f8f0db3ad1768b4388399fc0ce312482->leave($__internal_85698884d9b2329b4bcbdd7f3dd60b43f8f0db3ad1768b4388399fc0ce312482_prof);

    }

    public function getTemplateName()
    {
        return "NelmioApiDocBundle::Components/motd.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div class="motd"></div>*/
/* */
