<?php

/* @Twig/Exception/exception.json.twig */
class __TwigTemplate_770e334ac82aec27d3713009a8c5f5480ecf7c3d762cc0b3efc346f413c8baa0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8d18ec4c2445b02a568a95afedb00d85c418abf56f6d34dd19751fa8459b8423 = $this->env->getExtension("native_profiler");
        $__internal_8d18ec4c2445b02a568a95afedb00d85c418abf56f6d34dd19751fa8459b8423->enter($__internal_8d18ec4c2445b02a568a95afedb00d85c418abf56f6d34dd19751fa8459b8423_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "exception" => $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "toarray", array()))));
        echo "
";
        
        $__internal_8d18ec4c2445b02a568a95afedb00d85c418abf56f6d34dd19751fa8459b8423->leave($__internal_8d18ec4c2445b02a568a95afedb00d85c418abf56f6d34dd19751fa8459b8423_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {{ { 'error': { 'code': status_code, 'message': status_text, 'exception': exception.toarray } }|json_encode|raw }}*/
/* */
